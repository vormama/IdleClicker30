IDLE CLICKER 30 — проект Android Studio

Как получить APK:
1. Установи Android Studio на компьютер.
2. Открой папку IdleClicker30 через File → Open.
3. Дождись синхронизации Gradle (нужен интернет при первой сборке).
4. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Игра рассчитана на 30 минут: клики дают монеты, улучшения увеличивают доход в секунду,
прогресс сохраняется, после 30 минут показывается итог и доступен перезапуск.
