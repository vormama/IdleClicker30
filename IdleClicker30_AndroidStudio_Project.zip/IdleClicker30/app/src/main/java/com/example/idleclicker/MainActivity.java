package com.example.idleclicker;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final long TOTAL = 30 * 60 * 1000L;
    private final Handler handler = new Handler();
    private SharedPreferences prefs;
    private long startedAt, coins, taps, lastSaved;
    private int level;
    private TextView coinText, timeText, rateText, levelText, statusText;
    private Button clickButton, upgradeButton;
    private final int[] costs = {30, 120, 450, 1500, 5000};
    private final int[] rates = {1, 3, 8, 20, 55, 140};
    private final String[] stages = {"Первые монеты", "Маленький бизнес", "Фабрика монет", "Империя", "Космическая экономика", "Легенда кликера"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences("game", MODE_PRIVATE);
        coins = prefs.getLong("coins", 0);
        taps = prefs.getLong("taps", 0);
        level = prefs.getInt("level", 0);
        startedAt = prefs.getLong("startedAt", 0);
        if (startedAt == 0 || prefs.getBoolean("finished", false)) {
            startedAt = System.currentTimeMillis();
            coins = 0; taps = 0; level = 0;
            save(false);
        }
        buildUi();
        tick.run();
    }

    private TextView label(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER); t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setGravity(Gravity.CENTER);
        page.setPadding(24, 26, 24, 24); page.setBackgroundColor(Color.rgb(17,24,39));
        setContentView(page);
        TextView title = label("IDLE CLICKER", 28); page.addView(title);
        TextView subtitle = label("Твоя цель — построить империю за 30 минут", 14);
        page.addView(subtitle);
        coinText = label("🪙 0", 34); addSpace(page, 18); page.addView(coinText);
        timeText = label("30:00", 24); page.addView(timeText);
        levelText = label(stages[0], 18); addSpace(page, 8); page.addView(levelText);
        rateText = label("Доход: 1 монета/сек", 15); page.addView(rateText);
        clickButton = new Button(this); clickButton.setText("НАЖМИ МЕНЯ  +1 🪙");
        clickButton.setTextSize(20); addSpace(page, 22); page.addView(clickButton, full());
        clickButton.setOnClickListener(v -> { if (!ended()) { coins++; taps++; refresh(); } });
        upgradeButton = new Button(this); upgradeButton.setText("УЛУЧШИТЬ");
        addSpace(page, 12); page.addView(upgradeButton, full());
        upgradeButton.setOnClickListener(v -> buy());
        statusText = label("Покупай улучшения и увеличивай пассивный доход!", 13);
        addSpace(page, 14); page.addView(statusText);
        Button reset = new Button(this); reset.setText("Начать заново");
        addSpace(page, 8); page.addView(reset);
        reset.setOnClickListener(v -> {
            startedAt = System.currentTimeMillis(); coins=0; taps=0; level=0;
            prefs.edit().putBoolean("finished", false).apply(); save(false); refresh();
        });
        refresh();
    }
    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private void addSpace(LinearLayout l, int h) {
        Space s = new Space(this); l.addView(s, new LinearLayout.LayoutParams(1,h));
    }
    private void buy() {
        if (level >= costs.length) return;
        int cost = costs[level];
        if (coins >= cost) { coins -= cost; level++; refresh(); }
        else statusText.setText("Не хватает монет. Нажимай или подожди пассивный доход!");
    }
    private boolean ended() { return System.currentTimeMillis() - startedAt >= TOTAL; }
    private final Runnable tick = new Runnable() {
        public void run() {
            long elapsed = System.currentTimeMillis() - startedAt;
            long seconds = Math.min(1800, Math.max(0, elapsed / 1000));
            if (!prefs.getBoolean("finished", false)) coins += rates[level] ;
            if (elapsed >= TOTAL) {
                prefs.edit().putBoolean("finished", true).apply();
                clickButton.setEnabled(false); upgradeButton.setEnabled(false);
                statusText.setText("🏆 30 минут прошли! Ты заработал " + coins + " монет и сделал " + taps + " нажатий. Нажми «Начать заново» для новой игры.");
            }
            long left = Math.max(0, TOTAL - elapsed);
            timeText.setText(String.format(Locale.US, "%02d:%02d", left/60000, (left/1000)%60));
            refresh();
            if (System.currentTimeMillis() - lastSaved > 5000) { save(false); lastSaved=System.currentTimeMillis(); }
            if (elapsed < TOTAL) handler.postDelayed(this, 1000);
        }
    };
    private void refresh() {
        if (coinText == null) return;
        coinText.setText("🪙 " + coins);
        levelText.setText(stages[Math.min(level, stages.length-1)]);
        rateText.setText("Доход: " + rates[level] + " монет/сек  •  Нажатий: " + taps);
        if (level < costs.length) upgradeButton.setText("Улучшение " + (level+1) + " — " + costs[level] + " 🪙  (+" + (rates[level+1]-rates[level]) + "/сек)");
        else upgradeButton.setText("МАКСИМАЛЬНЫЙ УРОВЕНЬ");
        upgradeButton.setEnabled(level < costs.length && coins >= costs[level] && !ended());
        if (ended()) { timeText.setText("00:00"); clickButton.setEnabled(false); upgradeButton.setEnabled(false); }
    }
    private void save(boolean finished) {
        prefs.edit().putLong("coins",coins).putLong("taps",taps).putInt("level",level)
            .putLong("startedAt",startedAt).putBoolean("finished",finished).apply();
    }
    @Override protected void onPause() { super.onPause(); save(false); }
}
